package br.com.alura.cineb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinebApplication.class, args);
	}

}
